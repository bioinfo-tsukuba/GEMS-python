# Fixed-search-limit capacity study

Limits apply to each CP-SAT search. Construction, application and validation times are reference measurements and do not determine success. FEASIBLE is not an optimality proof. UNKNOWN is not an infeasibility proof. Delays use virtual minutes; computation uses real seconds.

| Pattern | Size | Phase | Limit s | Valid / runs | Search median / p95 / max s | Status |
| --- | ---: | --- | ---: | ---: | --- | --- |
| contention | 256 | operation | 1 | 1/1 | 18.015 / 18.015 / 18.015 | FEASIBLE |
| contention | 256 | scan | 1 | 1/1 | 1.002 / 1.002 / 1.002 | FEASIBLE |
| contention | 512 | scan | 60 | 1/1 | 60.005 / 60.005 / 60.005 | FEASIBLE |
| heterogeneous | 512 | operation | 1 | 1/1 | 18.040 / 18.040 / 18.040 | FEASIBLE |
| heterogeneous | 512 | scan | 1 | 1/1 | 1.004 / 1.004 / 1.004 | FEASIBLE |
| heterogeneous | 512 | scan | 60 | 1/1 | 59.988 / 59.988 / 59.988 | FEASIBLE |
| many_candidates | 64 | operation | 1 | 1/1 | 18.023 / 18.023 / 18.023 | FEASIBLE |
| many_candidates | 128 | operation | 1 | 0/1 | 3.717 / 3.717 / 3.717 | FEASIBLE, UNKNOWN |
| many_candidates | 128 | scan | 1 | 1/1 | 1.002 / 1.002 / 1.002 | FEASIBLE |
| many_candidates | 512 | scan | 60 | 1/1 | 60.007 / 60.007 / 60.007 | FEASIBLE |
| mixed_penalties | 64 | operation | 1 | 1/1 | 18.012 / 18.012 / 18.012 | FEASIBLE |
| mixed_penalties | 128 | operation | 1 | 0/1 | 1.567 / 1.567 / 1.567 | FEASIBLE, UNKNOWN |
| mixed_penalties | 128 | scan | 1 | 1/1 | 1.006 / 1.006 / 1.006 | FEASIBLE |
| mixed_penalties | 512 | scan | 60 | 1/1 | 60.010 / 60.010 / 60.010 | FEASIBLE |
| replanning | 256 | operation | 1 | 1/1 | 18.008 / 18.008 / 18.008 | FEASIBLE |
| replanning | 256 | scan | 1 | 1/1 | 1.002 / 1.002 / 1.002 | FEASIBLE |
| replanning | 512 | scan | 60 | 1/1 | 60.005 / 60.005 / 60.005 | FEASIBLE |

p95 uses linear interpolation; five repetitions do not establish an operational guarantee.
Memory includes the Python/OR-Tools imports. Utilization describes the pending schedule, not a calibrated facility throughput model.
